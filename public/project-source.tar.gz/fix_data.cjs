const store = {
  "students": [
    {
      "id": "st_sara",
      "name": "سارا احمدی",
      "grade": "دوازدهم / کنکور",
      "fieldOfStudy": "علوم تجربی",
      "targetGoal": "پزشکی دانشگاه تهران",
      "dailyTargetHours": 9,
      "wakeTime": "06:00",
      "sleepTime": "23:00",
      "strongSubjects": ["زیست‌شناسی", "شیمی"],
      "weakSubjects": ["ریاضی جامع", "فیزیک حرکت"],
      "schoolOrWorkHours": "۷:۳۰ تا ۱۳:۳۰",
      "additionalNotes": "اکانت نمونه",
      "hasPassword": false
    }
  ],
  "deletedStudents": [],
  "usageStats": {},
  "counselorConfig": {
    "username": "مشاور",
    "passcode": "1234",
    "passcodeHash": "pbkdf2:sha512:100000:626f158d3a441a25a464e09d8d345d27:8d36478233121098b9acad3a67582d08eae61252335a5da0e2e6eb1cfded18b844d4ddc778e6609432a40f52e3a32990dc5050af2d8a420a93e62d0fa4fb82d9",
    "announcement": "دانش‌آموزان عزیز، مهلت ارسال گزارش شبانه فراموش نشود!",
    "directive": ""
  },
  "securityAuditLogs": [],
  "updatedAt": new Date().toISOString()
};
require('fs').writeFileSync('data_students_registry.json', JSON.stringify(store, null, 2));

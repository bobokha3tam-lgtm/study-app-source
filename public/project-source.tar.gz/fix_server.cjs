const fs = require('fs');

let lines = fs.readFileSync('server.ts', 'utf-8').split('\n');

// Find the line with `// Vite middleware or static serving`
let viteLineIdx = lines.findIndex(l => l.includes('// Vite middleware or static serving'));
if (viteLineIdx !== -1) {
  // Replace everything after with the proper startServer block
  const newEnd = `
async function startServer() {
  try {
    const docRef = doc(db, 'system', 'store');
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      serverStudentStore = docSnap.data();
      console.log("Loaded student store from Firebase.");
    } else {
      console.log("No store in Firebase, using default.");
      // Save default store to Firebase to initialize it
      await setDoc(docRef, serverStudentStore);
    }
    isFirebaseReady = true;
  } catch (err) {
    console.error("Failed to fetch from Firebase, using local:", err);
    isFirebaseReady = true;
  }

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(\`Server running on http://localhost:\${PORT}\`);
  });
}

startServer();
`;

  const newLines = lines.slice(0, viteLineIdx + 1);
  fs.writeFileSync('server.ts', newLines.join('\n') + newEnd, 'utf-8');
  console.log("server.ts fixed");
} else {
  console.log("Could not find anchor line.");
}

import React, { useState } from 'react';
import { 
  Calendar, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  Circle, 
  BookOpen, 
  RefreshCw, 
  Copy, 
  Check, 
  Printer, 
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  HelpCircle,
  Play
} from 'lucide-react';
import { StudentProfile, WeeklySchedule, DaySchedule, StudyBlock } from '../types';
import { LiveFocusRoom } from './LiveFocusRoom';

interface WeeklyScheduleViewProps {
  schedule: WeeklySchedule;
  profile: StudentProfile;
  onUpdateSchedule: (newSchedule: WeeklySchedule) => void;
}

export const WeeklyScheduleView: React.FC<WeeklyScheduleViewProps> = ({
  schedule,
  profile,
  onUpdateSchedule,
}) => {
  const [activeDayIndex, setActiveDayIndex] = useState<number>(0);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [showGenerateModal, setShowGenerateModal] = useState<boolean>(false);
  const [focusNotes, setFocusNotes] = useState<string>('تمرکز ویژه روی تست‌زنی مباحث ضعیف و آزمون پایان هفته');
  const [reasoningMode, setReasoningMode] = useState<'deep_thinking' | 'fast_standard'>('deep_thinking');
  const [copied, setCopied] = useState<boolean>(false);
  const [activeFocusBlock, setActiveFocusBlock] = useState<StudyBlock | null>(null);

  const activeDay: DaySchedule = schedule.days[activeDayIndex] || schedule.days[0];

  // Calculate completion
  const allBlocks = schedule.days.flatMap(d => d.blocks);
  const completedBlocks = allBlocks.filter(b => b.isDone).length;
  const progressPercent = allBlocks.length > 0 ? Math.round((completedBlocks / allBlocks.length) * 100) : 0;
  const totalActualMinutes = allBlocks.reduce((acc, b) => acc + (b.actualDurationMinutes || 0), 0);
  const totalActualHours = (totalActualMinutes / 60).toFixed(1);

  const handleToggleBlock = (dayIndex: number, blockId: string) => {
    const newDays = [...schedule.days];
    const targetDay = { ...newDays[dayIndex] };
    targetDay.blocks = targetDay.blocks.map(b => 
      b.id === blockId ? { ...b, isDone: !b.isDone } : b
    );
    newDays[dayIndex] = targetDay;
    onUpdateSchedule({ ...schedule, days: newDays });
  };

  const handleFocusComplete = (actualMinutes: number) => {
    if (!activeFocusBlock) return;
    
    // Find and update the block in the schedule
    const newDays = [...schedule.days];
    const dayIndex = newDays.findIndex(d => d.blocks.some(b => b.id === activeFocusBlock.id));
    if (dayIndex !== -1) {
      const targetDay = { ...newDays[dayIndex] };
      targetDay.blocks = targetDay.blocks.map(b => 
        b.id === activeFocusBlock.id 
          ? { ...b, isDone: true, actualDurationMinutes: actualMinutes } 
          : b
      );
      newDays[dayIndex] = targetDay;
      onUpdateSchedule({ ...schedule, days: newDays });
    }
    setActiveFocusBlock(null);
  };

  const handleGenerateSchedule = async () => {
    setIsGenerating(true);
    try {
      let examBudget = undefined;
      let examErrors = [];
      let recentReports = [];

      try {
        const savedBudget = localStorage.getItem('study_advisor_exam_budget');
        if (savedBudget) examBudget = JSON.parse(savedBudget);

        const savedErrors = localStorage.getItem('study_advisor_error_logs');
        if (savedErrors) examErrors = JSON.parse(savedErrors);

        const savedReports = localStorage.getItem('study_advisor_reports');
        if (savedReports) recentReports = JSON.parse(savedReports);
      } catch (e) {
        // ignore
      }

      const response = await fetch('/api/advisor/generate-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile, focusNotes, examBudget, reasoningMode, examErrors, recentReports }),
      });

      if (!response.ok) {
        throw new Error('خطا در دریافت برنامه جدید از مشاور');
      }

      const data = await response.json();
      if (data.schedule && data.schedule.days) {
        const fullSchedule: WeeklySchedule = {
          ...data.schedule,
          id: `week-${Date.now()}`,
          createdAt: new Date().toISOString(),
        };
        onUpdateSchedule(fullSchedule);
        setShowGenerateModal(false);
      }
    } catch (err) {
      console.error('Error generating schedule:', err);
      alert('خطا در تولید برنامه با هوش مصنوعی. لطفاً اتصال اینترنت یا کلید Gemini را بررسی کنید.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyScheduleText = () => {
    let text = `📅 *${schedule.weekTitle}*\n`;
    text += `🎯 استراتژی هفته: ${schedule.strategySummary}\n`;
    text += `⏱ مجموع ساعات: ${schedule.totalPlannedHours} ساعت\n\n`;

    schedule.days.forEach(d => {
      text += `━━━━━━━━━━━━━━\n`;
      text += `📌 *${d.dayName}* (هدف: ${d.targetHours} ساعت)\n`;
      if (d.dailyTip) text += `💡 نکته روز: ${d.dailyTip}\n`;
      d.blocks.forEach(b => {
        text += `• [${b.timeSlot}] ${b.subject}: ${b.topic} (${b.durationMinutes} دقیقه)\n`;
      });
      text += `\n`;
    });

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const getBadgeStyle = (type: StudyBlock['type']) => {
    switch (type) {
      case 'concept':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'test':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'review':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'compensatory':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'class':
        return 'bg-rose-50 text-rose-700 border-rose-200 font-bold';
      case 'class_homework':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200 font-bold';
      default:
        return 'bg-stone-50 text-stone-700 border-stone-200';
    }
  };

  const getTypeName = (type: StudyBlock['type']) => {
    switch (type) {
      case 'concept': return 'یادگیری و مفهومی';
      case 'test': return 'تست و تمرین';
      case 'review': return 'مرور و بازیابی';
      case 'compensatory': return 'باکس جبرانی';
      case 'class': return '🏫 کلاس ثابت هفتگی';
      case 'class_homework': return '✍️ تکلیف و مرور کلاس';
      default: return 'مطالعه';
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Top Banner & Control */}
      <div className="bg-gradient-to-r from-stone-900 via-stone-800 to-emerald-950 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-emerald-900/40 relative overflow-hidden">
        {/* Background Radial Accent Glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-60 h-60 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                برنامه هوشمند حجمی-زمانی
              </span>
              <span className="text-xs text-stone-300 bg-white/10 px-2.5 py-1 rounded-full border border-white/10 font-semibold">
                هدف هفته: {schedule.totalPlannedHours} ساعت مطالعه
              </span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">{schedule.weekTitle}</h2>
            <p className="text-xs sm:text-sm text-stone-300 leading-relaxed font-normal">
              {schedule.strategySummary}
            </p>

            {/* Overall Progress Meter */}
            <div className="pt-2 flex items-center gap-4">
              <div className="flex-1 bg-stone-800/80 rounded-full h-2.5 overflow-hidden border border-white/10 p-0.5">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500 shadow-xs"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <span className="text-xs font-black text-emerald-400 shrink-0">
                {progressPercent}٪ تکمیل شده ({completedBlocks} از {allBlocks.length} باکس)
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={() => setShowGenerateModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-stone-950 text-xs font-black shadow-md hover:shadow-lg transition-all cursor-pointer group"
            >
              <RefreshCw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
              <span>بازتولید برنامه با AI</span>
            </button>

            <button
              onClick={handleCopyScheduleText}
              className="flex items-center gap-1.5 px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/15 transition-all cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'کپی شد' : 'اشتراک برنامه'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Progress Bar & Focus Tracker */}
      <div className="bg-white rounded-2xl p-4 border border-stone-200 shadow-xs space-y-2">
        <div className="flex flex-wrap justify-between items-center text-xs font-semibold gap-2">
          <span className="text-stone-700">میزان پیشرفت پارت‌های درسی این هفته:</span>
          <div className="flex items-center gap-3">
            {totalActualMinutes > 0 && (
              <span className="text-amber-700 font-bold bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-full text-[11px] flex items-center gap-1">
                ⏱️ زمان مطالعه واقعی: {totalActualHours} ساعت ({totalActualMinutes} دقیقه)
              </span>
            )}
            <span className="text-emerald-700 font-bold">{completedBlocks} از {allBlocks.length} پارت ({progressPercent}٪)</span>
          </div>
        </div>
        <div className="w-full bg-stone-100 rounded-full h-2.5 overflow-hidden">
          <div 
            className="bg-emerald-600 h-2.5 rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Days Navigation Tabs */}
      <div className="flex overflow-x-auto gap-2 pb-1 scrollbar-none">
        {schedule.days.map((day, idx) => {
          const isSelected = idx === activeDayIndex;
          const dayDoneCount = day.blocks.filter(b => b.isDone).length;
          return (
            <button
              key={idx}
              onClick={() => setActiveDayIndex(idx)}
              className={`flex-1 min-w-[100px] p-3 rounded-xl border text-right transition-all shrink-0 ${
                isSelected
                  ? 'bg-stone-900 text-white border-stone-900 shadow-xs'
                  : 'bg-white text-stone-700 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
              }`}
            >
              <div className="text-xs font-bold">{day.dayName}</div>
              <div className={`text-[11px] mt-1 flex items-center justify-between ${isSelected ? 'text-stone-300' : 'text-stone-400'}`}>
                <span>{day.targetHours}h</span>
                <span>{dayDoneCount}/{day.blocks.length} پارت</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Day Detail Card */}
      <div className="bg-white rounded-2xl p-6 border border-stone-200 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-stone-100 gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-stone-900">{activeDay.dayName}</h3>
              <span className="text-xs font-medium px-2 py-0.5 rounded-md bg-stone-100 text-stone-600">
                ساعت هدف: {activeDay.targetHours} ساعت
              </span>
            </div>
            {activeDay.dailyTip && (
              <p className="text-xs text-emerald-800 bg-emerald-50/70 border border-emerald-100 px-3 py-1.5 rounded-lg mt-2 inline-block">
                💡 {activeDay.dailyTip}
              </p>
            )}
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={() => setActiveDayIndex((prev) => (prev > 0 ? prev - 1 : schedule.days.length - 1))}
              className="p-2 rounded-lg border border-stone-200 hover:bg-stone-50 text-stone-600"
              title="روز قبل"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveDayIndex((prev) => (prev < schedule.days.length - 1 ? prev + 1 : 0))}
              className="p-2 rounded-lg border border-stone-200 hover:bg-stone-50 text-stone-600"
              title="روز بعد"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Study Blocks List */}
        <div className="space-y-3">
          {activeDay.blocks.map((block) => (
            <div
              key={block.id}
              onClick={() => handleToggleBlock(activeDayIndex, block.id)}
              className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-4 ${
                block.isDone
                  ? 'bg-stone-50 border-stone-200 text-stone-400 opacity-75'
                  : 'bg-white border-stone-200 hover:border-emerald-300 hover:shadow-xs'
              }`}
            >
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  className="text-stone-400 hover:text-emerald-600 transition-colors"
                >
                  {block.isDone ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-50" />
                  ) : (
                    <Circle className="w-5 h-5 text-stone-300" />
                  )}
                </button>

                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`text-sm font-bold ${block.isDone ? 'line-through text-stone-500' : 'text-stone-900'}`}>
                      {block.subject}
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-md border font-medium ${getBadgeStyle(block.type)}`}>
                      {getTypeName(block.type)}
                    </span>
                    {block.difficultyLevel && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">
                        {block.difficultyLevel}
                      </span>
                    )}
                    {block.targetTests && block.targetTests > 0 && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-300">
                        🎯 {block.targetTests} تست
                      </span>
                    )}
                  </div>
                  <div className={`text-xs mt-1 leading-relaxed ${block.isDone ? 'line-through text-stone-400' : 'text-stone-600'}`}>
                    {block.topic}
                    {block.recommendedMethod && (
                      <div className="mt-1.5 flex items-center gap-1 text-[11px] font-medium text-indigo-700 bg-indigo-50/70 border border-indigo-100 rounded-md px-2 py-1 w-max">
                        <Sparkles className="w-3 h-3" />
                        {block.recommendedMethod}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="text-left shrink-0 flex flex-col items-end gap-2">
                <div className="text-right">
                  <div className="text-xs font-semibold text-stone-700">{block.timeSlot}</div>
                  <div className="text-[11px] text-stone-400">
                    {block.actualDurationMinutes ? (
                      <span className="text-emerald-600 font-bold">{block.actualDurationMinutes} دقیقه ثبت شد</span>
                    ) : (
                      `${block.durationMinutes} دقیقه`
                    )}
                  </div>
                </div>
                
                {!block.isDone && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveFocusBlock(block);
                    }}
                    className="flex items-center gap-1 text-[10px] font-bold bg-amber-50 text-amber-700 hover:bg-amber-100 hover:text-amber-800 border border-amber-200 px-2.5 py-1.5 rounded-lg transition-colors"
                  >
                    <Play className="w-3 h-3" />
                    شروع تمرکز
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {activeFocusBlock && (
        <LiveFocusRoom
          block={activeFocusBlock}
          onClose={() => setActiveFocusBlock(null)}
          onComplete={handleFocusComplete}
        />
      )}

      {/* Generate Schedule Modal */}
      {showGenerateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-5">
            <div className="flex justify-between items-center pb-3 border-b border-stone-100">
              <h3 className="font-bold text-stone-900 text-base flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-600" />
                طراحی برنامه هفتگی اختصاصی با Gemini
              </h3>
              <button
                onClick={() => setShowGenerateModal(false)}
                className="text-stone-400 hover:text-stone-700"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs text-stone-600">
              <p>
                مشاور هوشمند با در نظر گرفتن اطلاعات پروفایلت (رشته {profile.fieldOfStudy}، هدف {profile.targetGoal}، و نقاط ضعف در {profile.weakSubjects.join(' و ')}) یک برنامه هفتگی حجمی-زمانی طراحی می‌کند.
              </p>

              {/* AI Engine Selection */}
              <div className="bg-stone-50 p-3 rounded-xl border border-stone-200 space-y-2">
                <label className="block text-xs font-bold text-stone-800">
                  موتور هوش مصنوعی برای برنامه‌ریزی:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setReasoningMode('deep_thinking')}
                    className={`p-2.5 rounded-xl border text-right transition-all flex flex-col gap-1 ${
                      reasoningMode === 'deep_thinking'
                        ? 'border-indigo-600 bg-indigo-50/70 text-indigo-950 shadow-xs'
                        : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs flex items-center gap-1.5 text-indigo-900">
                        🧠 تفکر عمیق و استراتژیست
                      </span>
                      {reasoningMode === 'deep_thinking' && (
                        <span className="text-[10px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-md font-bold">
                          فعال
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-stone-500 leading-tight">
                      تحلیل زنجیره تفکر، موازنه افت انرژی، فواصل لایتنر و چیدمان ضدشکنندگی
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setReasoningMode('fast_standard')}
                    className={`p-2.5 rounded-xl border text-right transition-all flex flex-col gap-1 ${
                      reasoningMode === 'fast_standard'
                        ? 'border-emerald-600 bg-emerald-50/70 text-emerald-950 shadow-xs'
                        : 'border-stone-200 bg-white text-stone-700 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs flex items-center gap-1.5 text-emerald-900">
                        ⚡ سریع و استاندارد
                      </span>
                      {reasoningMode === 'fast_standard' && (
                        <span className="text-[10px] bg-emerald-600 text-white px-1.5 py-0.5 rounded-md font-bold">
                          فعال
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-stone-500 leading-tight">
                      تولید پرسرعت در چند ثانیه با توزیع پیش‌فرض مباحث هفتگی
                    </span>
                  </button>
                </div>
              </div>

              {/* Auto-Feedback Data Status Badge */}
              <div className="bg-gradient-to-r from-amber-50 to-orange-50 p-3 rounded-xl border border-amber-200/80 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-amber-900 flex items-center gap-1.5">
                    🔄 داده‌های ورودی چرخه بازخورد هوشمند (Auto-Feedback)
                  </span>
                  <span className="text-[10px] bg-amber-200/80 text-amber-900 font-bold px-2 py-0.5 rounded-md">
                    تلفیق خودکار
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-amber-900/80">
                  <div className="bg-white/70 p-2 rounded-lg border border-amber-200/50 flex items-center gap-1.5">
                    <span>🩺 خطاهای آزمون:</span>
                    <span className="font-bold text-amber-950">
                      {(() => {
                        try {
                          const e = localStorage.getItem('study_advisor_error_logs');
                          return e ? JSON.parse(e).length : 0;
                        } catch { return 0; }
                      })()} مورد
                    </span>
                  </div>
                  <div className="bg-white/70 p-2 rounded-lg border border-amber-200/50 flex items-center gap-1.5">
                    <span>📊 گزارش‌کارهای اخیر:</span>
                    <span className="font-bold text-amber-950">
                      {(() => {
                        try {
                          const r = localStorage.getItem('study_advisor_reports');
                          return r ? JSON.parse(r).length : 0;
                        } catch { return 0; }
                      })()} ثبت‌شده
                    </span>
                  </div>
                </div>
                <p className="text-[10px] text-amber-800/80 leading-tight">
                  برنامه جدید با تحلیل نوسانات راندمان گزارش‌های اخیر و لکه‌گیری خطاهای کالبدشکافی چیده می‌شود.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">
                  اولویت یا خواسته ویژه برای این هفته:
                </label>
                <textarea
                  rows={3}
                  value={focusNotes}
                  onChange={e => setFocusNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-stone-300 text-xs focus:outline-emerald-600"
                  placeholder="مثلاً: این هفته آزمون قلم‌چی/گاج دارم، می‌خوام تست‌های شیمی و فیزیک بیشتر باشه..."
                />
              </div>

              <div className="flex flex-wrap gap-1.5 pt-1">
                {[
                  'تمرکز ویژه روی تست دروس ضعیف',
                  'هفته جمع‌بندی و آزمون آزمایشی',
                  'جبران عقب‌افتادگی‌های مباحث پایه',
                  'حالت فشرده با افزایش ۱ ساعت مطالعه روزانه'
                ].map((preset, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setFocusNotes(preset)}
                    className="px-2.5 py-1 rounded-md bg-stone-100 hover:bg-emerald-50 text-[11px] text-stone-700"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setShowGenerateModal(false)}
                className="px-4 py-2 text-xs text-stone-600 hover:text-stone-800"
              >
                انصراف
              </button>
              <button
                type="button"
                disabled={isGenerating}
                onClick={handleGenerateSchedule}
                className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs disabled:opacity-60"
              >
                {isGenerating ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    در حال چیدمان علمی برنامه...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    تولید برنامه ۷ روزه
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

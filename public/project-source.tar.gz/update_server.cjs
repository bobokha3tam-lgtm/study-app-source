const fs = require('fs');

let serverContent = fs.readFileSync('server.ts', 'utf-8');

// Insert Firebase imports at the top
const imports = `import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDoc, setDoc } from 'firebase/firestore';
`;
serverContent = imports + serverContent;

// Find the saveServerStudentStore and loadServerStudentStore
// We will modify startServer to load from Firebase, and saveServerStudentStore to write to Firebase.

// Insert Firebase initialization right after dotenv
const firebaseInit = `
const firebaseConfig = JSON.parse(fs.readFileSync(path.join(process.cwd(), 'firebase-applet-config.json'), 'utf-8'));
const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp, firebaseConfig.firestoreDatabaseId);

let isFirebaseReady = false;
`;

serverContent = serverContent.replace('const app = express();', firebaseInit + '\nconst app = express();');

// Update saveServerStudentStore
const newSaveFunction = `function saveServerStudentStore(store: ServerStudentStore) {
  try {
    fs.writeFileSync(STUDENTS_FILE_PATH, JSON.stringify(store, null, 2), "utf-8");
  } catch (e) {
    console.error("Error writing students registry file:", e);
  }
  
  // Save to Firebase asynchronously
  if (isFirebaseReady) {
    setDoc(doc(db, 'system', 'store'), store).catch(e => console.error("Firebase sync error:", e));
  }
}`;

serverContent = serverContent.replace(/function saveServerStudentStore\(store: ServerStudentStore\) \{[\s\S]*?\}\n/, newSaveFunction + '\n');

// Update startServer to await initial fetch
const startServerReplacement = `async function startServer() {
  try {
    const docRef = doc(db, 'system', 'store');
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      serverStudentStore = docSnap.data() as ServerStudentStore;
      console.log("Loaded student store from Firebase.");
    } else {
      console.log("No store in Firebase, using default.");
      // Save default store to Firebase to initialize it
      await setDoc(docRef, serverStudentStore);
    }
    isFirebaseReady = true;
  } catch (err) {
    console.error("Failed to fetch from Firebase, using local:", err);
    isFirebaseReady = true;
  }

  if (process.env.NODE_ENV !== "production") {`;

serverContent = serverContent.replace(/if \(process\.env\.NODE_ENV !== "production"\) \{/, startServerReplacement);

fs.writeFileSync('server.ts', serverContent, 'utf-8');
console.log("server.ts updated.");

// Just to check if we can write a function
